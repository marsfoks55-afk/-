import { audioSettings, AudioSettingsState } from './AudioSettings';

export type SoundEvent =
  // UI
  | 'button_click'
  | 'button_hover'
  | 'modal_open'
  | 'modal_close'
  | 'tab_switch'
  | 'toggle'
  | 'notification'
  // Case Opening
  | 'case_open'
  | 'roulette_start'
  | 'roulette_tick'
  | 'roulette_slowdown'
  | 'roulette_stop'
  | 'item_reveal'
  | 'rare_drop'
  | 'legendary_drop'
  // Upgrader
  | 'upgrade_start'
  | 'upgrade_spin'
  | 'upgrade_success'
  | 'upgrade_fail';

export class AudioManager {
  private static instance: AudioManager;
  private ctx: AudioContext | null = null;
  private settings: AudioSettingsState;
  private isUnlocked: boolean = false;
  private audioBuffers: Map<string, AudioBuffer> = new Map();
  private lastPlayTime: Map<string, number> = new Map();

  private constructor() {
    this.settings = audioSettings.getState();
    audioSettings.subscribe((s) => {
      this.settings = s;
    });

    if (typeof window !== 'undefined') {
      const unlockAudio = () => {
        this.unlockContext();
        window.removeEventListener('pointerdown', unlockAudio);
        window.removeEventListener('keydown', unlockAudio);
      };
      window.addEventListener('pointerdown', unlockAudio, { passive: true });
      window.addEventListener('keydown', unlockAudio, { passive: true });
    }
  }

  public static getInstance(): AudioManager {
    if (!AudioManager.instance) {
      AudioManager.instance = new AudioManager();
    }
    return AudioManager.instance;
  }

  private unlockContext(): void {
    if (typeof window === 'undefined') return;
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    this.isUnlocked = true;
  }

  private getEffectiveVolume(category: 'ui' | 'case' | 'upgrade'): number {
    if (!this.settings.soundEnabled || this.settings.isMuted) return 0;
    const catVol =
      category === 'ui'
        ? this.settings.uiVolume
        : category === 'case'
        ? this.settings.caseVolume
        : this.settings.upgradeVolume;

    return Math.max(0, Math.min(1, this.settings.masterVolume * catVol));
  }

  // Throttle helper to avoid sound cluttering
  private canPlay(soundId: string, minIntervalMs = 40): boolean {
    const now = performance.now();
    const last = this.lastPlayTime.get(soundId) || 0;
    if (now - last < minIntervalMs) return false;
    this.lastPlayTime.set(soundId, now);
    return true;
  }

  // Dispatch play
  public play(event: SoundEvent, options?: { pitch?: number; volumeMultiplier?: number; customFreq?: number }): void {
    if (!this.settings.soundEnabled || this.settings.isMuted) return;
    this.unlockContext();
    if (!this.ctx) return;

    const mult = options?.volumeMultiplier ?? 1.0;

    switch (event) {
      // UI
      case 'button_click': {
        if (!this.canPlay(event, 35)) return;
        const vol = this.getEffectiveVolume('ui') * 0.4 * mult;
        if (vol <= 0) return;
        this.synthClick(vol, options?.pitch ?? 1.0);
        break;
      }
      case 'button_hover': {
        if (!this.canPlay(event, 60)) return;
        const vol = this.getEffectiveVolume('ui') * 0.12 * mult;
        if (vol <= 0) return;
        this.synthHover(vol);
        break;
      }
      case 'modal_open': {
        const vol = this.getEffectiveVolume('ui') * 0.5 * mult;
        if (vol <= 0) return;
        this.synthModal(vol, true);
        break;
      }
      case 'modal_close': {
        const vol = this.getEffectiveVolume('ui') * 0.45 * mult;
        if (vol <= 0) return;
        this.synthModal(vol, false);
        break;
      }
      case 'tab_switch': {
        if (!this.canPlay(event, 50)) return;
        const vol = this.getEffectiveVolume('ui') * 0.35 * mult;
        if (vol <= 0) return;
        this.synthTab(vol);
        break;
      }
      case 'toggle': {
        const vol = this.getEffectiveVolume('ui') * 0.4 * mult;
        if (vol <= 0) return;
        this.synthToggle(vol);
        break;
      }
      case 'notification': {
        const vol = this.getEffectiveVolume('ui') * 0.5 * mult;
        if (vol <= 0) return;
        this.synthNotification(vol);
        break;
      }

      // Case Opening
      case 'case_open': {
        const vol = this.getEffectiveVolume('case') * 0.7 * mult;
        if (vol <= 0) return;
        this.synthCaseUnlock(vol);
        break;
      }
      case 'roulette_start': {
        const vol = this.getEffectiveVolume('case') * 0.65 * mult;
        if (vol <= 0) return;
        this.synthRouletteStart(vol);
        break;
      }
      case 'roulette_tick': {
        // High performance mechanical roulette tick
        const vol = this.getEffectiveVolume('case') * 0.45 * mult;
        if (vol <= 0) return;
        const freq = options?.customFreq ?? 880;
        this.synthRouletteTick(vol, freq);
        break;
      }
      case 'roulette_slowdown': {
        const vol = this.getEffectiveVolume('case') * 0.55 * mult;
        if (vol <= 0) return;
        this.synthSlowdownTension(vol);
        break;
      }
      case 'roulette_stop': {
        const vol = this.getEffectiveVolume('case') * 0.8 * mult;
        if (vol <= 0) return;
        this.synthRouletteStop(vol);
        break;
      }
      case 'item_reveal': {
        const vol = this.getEffectiveVolume('case') * 0.7 * mult;
        if (vol <= 0) return;
        this.synthItemReveal(vol);
        break;
      }
      case 'rare_drop': {
        const vol = this.getEffectiveVolume('case') * 0.85 * mult;
        if (vol <= 0) return;
        this.synthRareDrop(vol);
        break;
      }
      case 'legendary_drop': {
        const vol = this.getEffectiveVolume('case') * 0.95 * mult;
        if (vol <= 0) return;
        this.synthLegendaryDrop(vol);
        break;
      }

      // Upgrader
      case 'upgrade_start': {
        const vol = this.getEffectiveVolume('upgrade') * 0.6 * mult;
        if (vol <= 0) return;
        this.synthUpgradeStart(vol);
        break;
      }
      case 'upgrade_spin': {
        const vol = this.getEffectiveVolume('upgrade') * 0.35 * mult;
        if (vol <= 0) return;
        const freq = options?.customFreq ?? 650;
        this.synthRouletteTick(vol, freq);
        break;
      }
      case 'upgrade_success': {
        const vol = this.getEffectiveVolume('upgrade') * 0.85 * mult;
        if (vol <= 0) return;
        this.synthUpgradeSuccess(vol);
        break;
      }
      case 'upgrade_fail': {
        const vol = this.getEffectiveVolume('upgrade') * 0.7 * mult;
        if (vol <= 0) return;
        this.synthUpgradeFail(vol);
        break;
      }
    }
  }

  // --- High-Fidelity Synthesizers with Web Audio API ---

  // UI Click: crisp metallic-digital micro transient
  private synthClick(vol: number, pitch = 1.0): void {
    if (!this.ctx) return;
    try {
      const t = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(620 * pitch, t);
      osc.frequency.exponentialRampToValueAtTime(140 * pitch, t + 0.035);

      gain.gain.setValueAtTime(vol * 0.7, t);
      gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.035);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(t);
      osc.stop(t + 0.035);
    } catch {}
  }

  // UI Hover: ultra-subtle air flick
  private synthHover(vol: number): void {
    if (!this.ctx) return;
    try {
      const t = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(420, t);
      osc.frequency.exponentialRampToValueAtTime(540, t + 0.02);

      gain.gain.setValueAtTime(vol * 0.3, t);
      gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.02);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(t);
      osc.stop(t + 0.02);
    } catch {}
  }

  // Modal open/close sweep
  private synthModal(vol: number, isOpen: boolean): void {
    if (!this.ctx) return;
    try {
      const t = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sine';
      const startFreq = isOpen ? 220 : 440;
      const endFreq = isOpen ? 440 : 220;

      osc.frequency.setValueAtTime(startFreq, t);
      osc.frequency.exponentialRampToValueAtTime(endFreq, t + 0.08);

      gain.gain.setValueAtTime(0.001, t);
      gain.gain.linearRampToValueAtTime(vol * 0.5, t + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.08);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(t);
      osc.stop(t + 0.08);
    } catch {}
  }

  private synthTab(vol: number): void {
    if (!this.ctx) return;
    try {
      const t = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(480, t);
      osc.frequency.exponentialRampToValueAtTime(720, t + 0.04);

      gain.gain.setValueAtTime(vol * 0.5, t);
      gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.04);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(t);
      osc.stop(t + 0.04);
    } catch {}
  }

  private synthToggle(vol: number): void {
    if (!this.ctx) return;
    try {
      const t = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(320, t);
      osc.frequency.setValueAtTime(580, t + 0.03);

      gain.gain.setValueAtTime(vol * 0.6, t);
      gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.07);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(t);
      osc.stop(t + 0.07);
    } catch {}
  }

  private synthNotification(vol: number): void {
    if (!this.ctx) return;
    try {
      const t = this.ctx.currentTime;
      const notes = [587.33, 880];
      notes.forEach((freq, idx) => {
        if (!this.ctx) return;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, t + idx * 0.06);

        gain.gain.setValueAtTime(0, t + idx * 0.06);
        gain.gain.linearRampToValueAtTime(vol * 0.5, t + idx * 0.06 + 0.015);
        gain.gain.exponentialRampToValueAtTime(0.0001, t + idx * 0.06 + 0.25);

        osc.connect(gain);
        gain.connect(this.ctx.destination);

        osc.start(t + idx * 0.06);
        osc.stop(t + idx * 0.06 + 0.25);
      });
    } catch {}
  }

  // Case Unlock Mechanical Latch
  private synthCaseUnlock(vol: number): void {
    if (!this.ctx) return;
    try {
      const t = this.ctx.currentTime;
      // Mechanical latch 1
      const osc1 = this.ctx.createOscillator();
      const gain1 = this.ctx.createGain();
      osc1.type = 'square';
      osc1.frequency.setValueAtTime(140, t);
      osc1.frequency.exponentialRampToValueAtTime(60, t + 0.08);

      gain1.gain.setValueAtTime(vol * 0.7, t);
      gain1.gain.exponentialRampToValueAtTime(0.0001, t + 0.08);
      osc1.connect(gain1);
      gain1.connect(this.ctx.destination);
      osc1.start(t);
      osc1.stop(t + 0.08);

      // Pneumatic whoosh
      const osc2 = this.ctx.createOscillator();
      const gain2 = this.ctx.createGain();
      osc2.type = 'sawtooth';
      osc2.frequency.setValueAtTime(320, t + 0.05);
      osc2.frequency.exponentialRampToValueAtTime(780, t + 0.22);

      gain2.gain.setValueAtTime(0, t + 0.05);
      gain2.gain.linearRampToValueAtTime(vol * 0.45, t + 0.1);
      gain2.gain.exponentialRampToValueAtTime(0.0001, t + 0.25);
      osc2.connect(gain2);
      gain2.connect(this.ctx.destination);
      osc2.start(t + 0.05);
      osc2.stop(t + 0.25);
    } catch {}
  }

  private synthRouletteStart(vol: number): void {
    if (!this.ctx) return;
    try {
      const t = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(150, t);
      osc.frequency.exponentialRampToValueAtTime(450, t + 0.18);

      gain.gain.setValueAtTime(vol * 0.5, t);
      gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.2);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(t);
      osc.stop(t + 0.2);
    } catch {}
  }

  // The critical mechanical tick for roulette reel passes
  private synthRouletteTick(vol: number, freq = 880): void {
    if (!this.ctx) return;
    try {
      const t = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, t);
      osc.frequency.exponentialRampToValueAtTime(110, t + 0.022);

      gain.gain.setValueAtTime(vol * 0.6, t);
      gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.022);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(t);
      osc.stop(t + 0.022);
    } catch {}
  }

  private synthSlowdownTension(vol: number): void {
    if (!this.ctx) return;
    try {
      const t = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(260, t);
      osc.frequency.linearRampToValueAtTime(180, t + 0.2);

      gain.gain.setValueAtTime(0.001, t);
      gain.gain.linearRampToValueAtTime(vol * 0.4, t + 0.05);
      gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.25);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(t);
      osc.stop(t + 0.25);
    } catch {}
  }

  // Final stop heavy latch
  private synthRouletteStop(vol: number): void {
    if (!this.ctx) return;
    try {
      const t = this.ctx.currentTime;
      // High snap
      const osc1 = this.ctx.createOscillator();
      const gain1 = this.ctx.createGain();
      osc1.type = 'triangle';
      osc1.frequency.setValueAtTime(1200, t);
      osc1.frequency.exponentialRampToValueAtTime(250, t + 0.04);
      gain1.gain.setValueAtTime(vol * 0.8, t);
      gain1.gain.exponentialRampToValueAtTime(0.0001, t + 0.04);
      osc1.connect(gain1);
      gain1.connect(this.ctx.destination);
      osc1.start(t);
      osc1.stop(t + 0.04);

      // Low bass impact
      const osc2 = this.ctx.createOscillator();
      const gain2 = this.ctx.createGain();
      osc2.type = 'sine';
      osc2.frequency.setValueAtTime(110, t);
      osc2.frequency.exponentialRampToValueAtTime(45, t + 0.2);
      gain2.gain.setValueAtTime(vol * 0.7, t);
      gain2.gain.exponentialRampToValueAtTime(0.0001, t + 0.2);
      osc2.connect(gain2);
      gain2.connect(this.ctx.destination);
      osc2.start(t);
      osc2.stop(t + 0.2);
    } catch {}
  }

  // Item Reveal
  private synthItemReveal(vol: number): void {
    if (!this.ctx) return;
    try {
      const t = this.ctx.currentTime;
      const freqs = [523.25, 659.25, 783.99, 1046.5]; // C major
      freqs.forEach((f, i) => {
        if (!this.ctx) return;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(f, t + i * 0.05);

        gain.gain.setValueAtTime(0, t + i * 0.05);
        gain.gain.linearRampToValueAtTime(vol * 0.45, t + i * 0.05 + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.0001, t + i * 0.05 + 0.4);

        osc.connect(gain);
        gain.connect(this.ctx.destination);

        osc.start(t + i * 0.05);
        osc.stop(t + i * 0.05 + 0.4);
      });
    } catch {}
  }

  // Rare Drop (Classified / Covert)
  private synthRareDrop(vol: number): void {
    if (!this.ctx) return;
    try {
      const t = this.ctx.currentTime;
      const freqs = [440, 554.37, 659.25, 880, 1108.73];
      freqs.forEach((f, i) => {
        if (!this.ctx) return;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(f, t + i * 0.06);

        gain.gain.setValueAtTime(0, t + i * 0.06);
        gain.gain.linearRampToValueAtTime(vol * 0.35, t + i * 0.06 + 0.03);
        gain.gain.exponentialRampToValueAtTime(0.0001, t + i * 0.06 + 0.7);

        osc.connect(gain);
        gain.connect(this.ctx.destination);

        osc.start(t + i * 0.06);
        osc.stop(t + i * 0.06 + 0.7);
      });
    } catch {}
  }

  // Legendary Drop (Knife / Gloves / Extraordinary)
  private synthLegendaryDrop(vol: number): void {
    if (!this.ctx) return;
    try {
      const t = this.ctx.currentTime;
      // Golden cinematic chime
      const freqs = [587.33, 739.99, 880, 1174.66, 1479.98, 1760];
      freqs.forEach((f, i) => {
        if (!this.ctx) return;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = i % 2 === 0 ? 'sine' : 'triangle';
        osc.frequency.setValueAtTime(f, t + i * 0.05);

        gain.gain.setValueAtTime(0, t + i * 0.05);
        gain.gain.linearRampToValueAtTime(vol * 0.4, t + i * 0.05 + 0.04);
        gain.gain.exponentialRampToValueAtTime(0.0001, t + i * 0.05 + 1.2);

        osc.connect(gain);
        gain.connect(this.ctx.destination);

        osc.start(t + i * 0.05);
        osc.stop(t + i * 0.05 + 1.2);
      });
    } catch {}
  }

  // Upgrader Start
  private synthUpgradeStart(vol: number): void {
    if (!this.ctx) return;
    try {
      const t = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(280, t);
      osc.frequency.exponentialRampToValueAtTime(620, t + 0.15);

      gain.gain.setValueAtTime(vol * 0.5, t);
      gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.18);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(t);
      osc.stop(t + 0.18);
    } catch {}
  }

  private synthUpgradeSuccess(vol: number): void {
    this.synthLegendaryDrop(vol);
  }

  private synthUpgradeFail(vol: number): void {
    if (!this.ctx) return;
    try {
      const t = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(190, t);
      osc.frequency.exponentialRampToValueAtTime(65, t + 0.35);

      gain.gain.setValueAtTime(vol * 0.6, t);
      gain.gain.exponentialRampToValueAtTime(0.0001, t + 0.35);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(t);
      osc.stop(t + 0.35);
    } catch {}
  }
}

export const audioManager = AudioManager.getInstance();
